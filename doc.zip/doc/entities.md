# Entitats del Sistema

## Video

## Video Cataleg

## Usuari

## Categoria

## Serie

## Estudi

## Suscripcio

## Metode Pago

## Perfil

## Historial de Reproduccions
