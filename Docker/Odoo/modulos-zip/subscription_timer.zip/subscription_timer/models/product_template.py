from odoo import models, fields, api

class ProductTemplate(models.Model):
    """
    Extensión de la plantilla de producto para añadir configuración de suscripciones.
    Permite definir qué productos disparan la creación de una suscripción y su duración.
    """
    _inherit = 'product.template'
    
    is_subscription = fields.Boolean(
        string='Es Suscripción',
        default=False,
        help='Marca si este producto es un plan de suscripción'
    )
    
    subscription_days = fields.Integer(
        string='Días de Suscripción',
        default=30,
        help='Número de días que dura la suscripción'
    )