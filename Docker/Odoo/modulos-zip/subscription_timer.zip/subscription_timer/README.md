# Gestión de Suscripciones con Temporizador

Este módulo permite la creación y gestión automática de suscripciones de clientes basadas en productos comprados mediante pedidos de venta.

## Funcionalidades Principales

- **Automatización**: Creación automática de suscripciones al confirmar un `Sale Order`.
- **Configuración de Productos**: Campos en la plantilla de producto para marcar si es una suscripción y definir su duración en días.
- **Seguimiento en Tiempo Real**: 
  - Cálculo automático de fecha de fin.
  - Contador de días restantes.
  - Barra de progreso visual según el tiempo transcurrido.
- **Gestión de Expiración**: Proceso automático (Cron) que marca las suscripciones como expiradas al llegar a la fecha límite.
- **Integración con Portal**: (Opcional) Permite a los clientes visualizar sus suscripciones activas.
