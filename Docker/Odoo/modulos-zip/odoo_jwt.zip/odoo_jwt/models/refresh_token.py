from odoo import models, fields

class JwtRefreshToken(models.Model):
    """
    Modelo encargado de almacenar los Refresh Tokens persistentes en la base de datos.
    Permite el seguimiento de sesiones de larga duración y la revocación manual de accesos.
    """
    _name = 'jwt.refresh_token'
    _description = 'JWT Refresh Token'

    is_revoked = fields.Boolean(index=True)
    stored_token = fields.Text(required=True, index=True)
    user_id = fields.Many2one('res.users', required=True, ondelete='cascade', index=True)
