import os
import jwt
import logging
from datetime import datetime, timedelta
from odoo.exceptions import AccessDenied

_logger = logging.getLogger(__name__)

class JwtToken:
    JWT_ALGORITHM = 'RS256'
    ACCESS_TOKEN_SECONDS = 60
    REFRESH_TOKEN_SECONDS = 3600

    @classmethod
    def _get_key_from_file(cls, filename):
        key_path = os.path.join(os.path.dirname(__file__), 'keys', filename)
        if os.path.exists(key_path):
            with open(key_path, "rb") as f:
                return f.read()
        return None

    @classmethod
    def get_private_key(cls):
        return cls._get_key_from_file('private.pem')

    @classmethod
    def get_public_key(cls):
        return cls._get_key_from_file('public.pem')

    @classmethod
    def generate_token(cls, user_id, duration=0, extra_payload=None):
        if not duration:
            duration = cls.ACCESS_TOKEN_SECONDS

        payload = {
            'user_id': user_id,
            'exp': datetime.utcnow() + timedelta(seconds=duration)
        }

        if extra_payload:
            payload.update(extra_payload)

        private_key = cls.get_private_key()
        if not private_key:
             raise Exception("Private key not found for JWT signing")
             
        return jwt.encode(payload, private_key, algorithm=cls.JWT_ALGORITHM)

    @classmethod
    def create_refresh_token(cls, req, uid):
        new_token = cls.generate_token(uid, JwtToken.REFRESH_TOKEN_SECONDS)
        refresh_model = req.env['jwt.refresh_token'].sudo()
        existing_token = refresh_model.search([('user_id', '=', uid)])
        if existing_token:
            existing_token.write({'stored_token': new_token, 'is_revoked': False})
        else:
            refresh_model.create({'stored_token': new_token, 'user_id': uid})
        
        if hasattr(req, 'future_response'):
             req.future_response.set_cookie('refreshToken', new_token, httponly=True, secure=True, samesite='Lax')
        return new_token

    @classmethod
    def verify_refresh_token(cls, req, token, uid=None):
        try:
            public_key = cls.get_public_key()
            if not public_key:
                raise Exception("Public key not found for verification")
            
            payload = jwt.decode(token, public_key, algorithms=[cls.JWT_ALGORITHM])
            token_uid = payload.get('user_id')
            if not token_uid:
                raise AccessDenied('User ID missing in token payload')
            
            if uid and int(uid) != int(token_uid):
                raise AccessDenied('Token user ID mismatch')
            
            uid = token_uid
        except Exception as e:
            _logger.error("JWT Decode Error: %s", str(e))
            if isinstance(e, AccessDenied):
                raise e
            raise AccessDenied('Refresh Token has been expired or is invalid')

        tok_ob = req.env['jwt.refresh_token'].sudo().search([('user_id', '=', int(uid))], limit=1)
        if not tok_ob:
            raise AccessDenied('Refresh Token is invalid - No record found in DB')
            
        if tok_ob.stored_token != token:
            _logger.error("Refresh Token Mismatch for UID %s", uid)
            raise AccessDenied('Refresh Token has been changed')
            
        if tok_ob.is_revoked:
            raise AccessDenied('Token has been revoked => User Logged out, Please Log in again')
        
        return uid
