import os
import jwt
import logging
from datetime import datetime, timedelta
from odoo.exceptions import AccessDenied

_logger = logging.getLogger(__name__)

class JwtToken:
    """
    Clase de utilidad encargada de todas las operaciones criptográficas relacionadas con JWT.
    Gestión de claves PEM, generación de payloads y validación de firmas.
    """
    JWT_ALGORITHM = 'RS256'
    ACCESS_TOKEN_SECONDS = 86400
    REFRESH_TOKEN_SECONDS = 86400

    @classmethod
    def _get_key_from_file(cls, filename):
        """
        Recupera el contenido de una clave física desde el sistema de archivos.
        Las claves deben estar ubicadas en la carpeta 'keys' dentro del módulo.
        """
        key_path = os.path.join(os.path.dirname(__file__), 'keys', filename)
        if os.path.exists(key_path):
            with open(key_path, "rb") as f:
                return f.read()
        return None

    @classmethod
    def get_private_key(cls):
        """Devuelve el contenido de la clave privada para la firma de tokens."""
        return cls._get_key_from_file('private.pem')

    @classmethod
    def get_public_key(cls):
        """Devuelve el contenido de la clave pública para la verificación de tokens."""
        return cls._get_key_from_file('public.pem')

    @classmethod
    def generate_token(cls, user_id, duration=0, extra_payload=None):
        """
        Genera un JWT firmado con la clave privada.
        Se puede especificar una duración personalizada y datos adicionales para el payload.
        """
        if not duration:
            duration = cls.ACCESS_TOKEN_SECONDS

        payload = {
            'user_id': user_id,
            'exp': datetime.utcnow() + timedelta(seconds=duration)
        }

        if extra_payload:
            payload.update(extra_payload)

        private_key = cls.get_private_key()
        if not private_key:
             raise Exception("Private key not found for JWT signing")
             
        return jwt.encode(payload, private_key, algorithm=cls.JWT_ALGORITHM)

    @classmethod
    def create_refresh_token(cls, req, uid):
        """
        Crea un nuevo Refresh Token para un usuario y lo persiste en la base de datos.
        Si ya existe un token para ese usuario, se actualiza en lugar de crear uno nuevo.
        """
        new_token = cls.generate_token(uid, JwtToken.REFRESH_TOKEN_SECONDS)
        refresh_model = req.env['jwt.refresh_token'].sudo()
        existing_token = refresh_model.search([('user_id', '=', uid)])
        if existing_token:
            existing_token.write({'stored_token': new_token, 'is_revoked': False})
        else:
            refresh_model.create({'stored_token': new_token, 'user_id': uid})
        
        # Envío del token en una cookie si la respuesta soporta manipulación de cabeceras futuras
        if hasattr(req, 'future_response'):
             req.future_response.set_cookie('refreshToken', new_token, httponly=True, secure=True, samesite='Lax')
        return new_token

    @classmethod
    def verify_refresh_token(cls, req, token, uid=None):
        """
        Valida un Refresh Token comprobando su firma, expiración y presencia en base de datos.
        También verifica si el token ha sido marcado como revocado.
        """
        try:
            public_key = cls.get_public_key()
            if not public_key:
                raise Exception("Public key not found for verification")
            
            # Validación criptográfica del token
            payload = jwt.decode(token, public_key, algorithms=[cls.JWT_ALGORITHM])
            token_uid = payload.get('user_id')
            if not token_uid:
                raise AccessDenied('User ID missing in token payload')
            
            # Verificación de que el token pertenece al usuario que realiza la petición
            if uid and int(uid) != int(token_uid):
                raise AccessDenied('Token user ID mismatch')
            
            uid = token_uid
        except Exception as e:
            _logger.error("JWT Decode Error: %s", str(e))
            if isinstance(e, AccessDenied):
                raise e
            raise AccessDenied('Refresh Token has been expired or is invalid')

        # Validación final contra el registro persistente en la base de datos de Odoo
        tok_ob = req.env['jwt.refresh_token'].sudo().search([('user_id', '=', int(uid))], limit=1)
        if not tok_ob:
            raise AccessDenied('Refresh Token is invalid - No record found in DB')
            
        if tok_ob.stored_token != token:
            _logger.error("Refresh Token Mismatch for UID %s", uid)
            raise AccessDenied('Refresh Token has been changed')
            
        if tok_ob.is_revoked:
            raise AccessDenied('Token has been revoked => User Logged out, Please Log in again')
        
        return uid
