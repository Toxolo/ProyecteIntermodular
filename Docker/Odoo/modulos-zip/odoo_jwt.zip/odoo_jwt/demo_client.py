import requests
import jwt # necesita: pip install pyjwt cryptography
import json

# URL de tu instancia de Odoo
BASE_URL = "http://localhost:8069"
# Configuración por defecto (puedes cambiarlas aquí o te pedirá por teclado)
DEFAULT_DB = "Padalustro" 

def get_credentials():
    print(f"--- Configuración de Conexión ---")
    db = input(f"Base de Datos [{DEFAULT_DB}]: ").strip() or DEFAULT_DB
    login = input("Email/Usuario: ").strip()
    password = input("Contraseña: ").strip()
    return db, login, password

# La CLAVE PÚBLICA (Esta es la que compartirías con tus apps externas)
# Coincide con la clave privada que está actualmente en el servidor.
PUBLIC_KEY = """-----BEGIN RSA PUBLIC KEY-----
MIIBCgKCAQEAuxmAFxFx2pv5M3/Nw7Rvph8rrcxsZSiU4czaVeCBBqK0+DuQMVPo
knNdLaHUoO9dy5uIBDpNO8ZYi2KL4Bo0D1UfLwTHk6LvsRdKnYoPjXEtK2tyTOcS
XIPA35mWf29kX9IJcUCHfDs73xVW5eauF3MVhdJMVlSsLv/bE/4fr27fnp5EwrV2
E8edf3SNBSmLCgZM0V5qckFFCLrXz/7qexRqc93r1dbbTz1R8eys39ZSGcW7i4Cj
MHkuih+sSG/yXE1AKTw7XpAu92JhhCt82VyBA1g/d3cSNaSfsw17qBQU29bjNF35
DJ/0eI1zvGBs8R8XczbI++Qb7h6BWQizXwIDAQAB
-----END RSA PUBLIC KEY-----"""

def authenticate_and_verify():
    # Pedir credenciales al usuario
    db, login, password = get_credentials()

    url = f"{BASE_URL}/api/authenticate"
    payload = {
        "params": {
            "db": db,
            "login": login,
            "password": password
        }
    }
    
    print(f"Conectando a {url}...")
    try:
        response = requests.post(url, json=payload)
        response.raise_for_status()
        
        result = response.json()
        
        if result.get("error"):
            print(f"❌ Error desde Odoo: {result['error']}")
            return

        data = result.get("result", {}) # Empaquetado de Odoo
        if not data: 
             data = result # A veces, dependiendo de la decoración del controlador, puede ser directo
        
        access_token = data.get("token") or data.get("access_token")
        
        if not access_token:
            print("❌ No se encontró token en la respuesta:")
            print(json.dumps(result, indent=2))
            return

        print(f"\n✅ Token Recibido: {access_token[:20]}...")
        
        # Ahora VERIFICAMOS el token usando la Clave Pública, independientemente de Odoo
        print("\n🔍 Verificando token con la Clave Pública...")
        
        try:
            # decode verify=True por defecto, usando RS256
            decoded_payload = jwt.decode(
                access_token, 
                PUBLIC_KEY, 
                algorithms=["RS256"]
            )
            
            print("✅ Firma del Token Verificada Exitosamente!")
            print("📜 Datos del Token Desencriptados:")
            print(json.dumps(decoded_payload, indent=2))
            
        except jwt.ExpiredSignatureError:
            print("❌ El Token ha expirado!")
        except jwt.InvalidSignatureError:
            print("❌ Firma Inválida! El token no fue firmado por la Clave Privada correspondiente.")
        except Exception as e:
            print(f"❌ Falló la verificación: {e}")

    except requests.exceptions.ConnectionError:
        print("❌ No se pudo conectar a Odoo. ¿Está arrancado?")
    except Exception as e:
        print(f"❌ Error: {e}")

if __name__ == "__main__":
    authenticate_and_verify()
