from odoo.tests import TransactionCase
from ..setup.jwt_token import JwtToken
import jwt
import os

class TestRS256Auth(TransactionCase):

    def setUp(self):
        super().setUp()
        self.user_id = self.env.ref('base.user_admin').id

    def test_keys_generated(self):
        """Test that keys are generated on demand."""
        # Ensure we have keys
        JwtToken.get_public_key()
        
        # Check files exist
        setup_dir = os.path.dirname(os.path.abspath(JwtToken.__file__)) # slightly different way to find it effectively
        # But JwtToken internal paths rely on __file__ inside that module
        private_path = os.path.join(setup_dir, 'keys', 'private.pem')
        public_path = os.path.join(setup_dir, 'keys', 'public.pem')
        
        self.assertTrue(os.path.exists(private_path), "Private key should exist")
        self.assertTrue(os.path.exists(public_path), "Public key should exist")

    def test_token_signing_rs256(self):
        """Test that token is signed with RS256 and can be decoded with public key."""
        token = JwtToken.generate_token(self.user_id)
        
        # Verify header specifies RS256
        headers = jwt.get_unverified_header(token)
        self.assertEqual(headers['alg'], 'RS256')
        
        # Verify content with Public Key
        public_key = JwtToken.get_public_key()
        payload = jwt.decode(token, public_key, algorithms=['RS256'])
        self.assertEqual(payload['user_id'], self.user_id)

    def test_invalid_signature(self):
        """Test that tampering with the token invalidates it."""
        valid_token = JwtToken.generate_token(self.user_id)
        
        # Tamper with the payload part of JWT (header.payload.signature)
        parts = valid_token.split('.')
        # Just simple tamper could be decode, change, re-encode without signature
        # But easier: just change a char in the signature or payload
        tampered_token = parts[0] + '.' + parts[1] + '.' + parts[2][:-1] + 'A'
        
        public_key = JwtToken.get_public_key()
        
        with self.assertRaises(jwt.InvalidSignatureError):
            jwt.decode(tampered_token, public_key, algorithms=['RS256'])
