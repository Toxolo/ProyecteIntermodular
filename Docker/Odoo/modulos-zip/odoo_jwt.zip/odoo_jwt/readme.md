# Módulo Odoo JWT

Este módulo implementa un sistema de autenticación basado en **JSON Web Tokens (JWT)** para la API de Odoo.

## Funcionalidades Principales

- **Autenticación sin estado**: Utiliza tokens para validar la identidad del usuario sin depender de sesiones de servidor tradicionales.
- **RS256**: Generación de firmas criptográficas robustas utilizando claves asimétricas (PEM).
- **Control de Tokens**:
  - **Access Tokens**: Tokens de corta duración (60s) para acceso inmediato.
  - **Refresh Tokens**: Tokens de larga duración (1h) almacenados en base de datos para renovación de sesiones.
- **Integración Nativa**: Sobrescribe `ir.http` para permitir el método de autenticación `auth='jwt'`.

## Endpoints API

- `/api/authenticate`: Inicio de sesión y entrega de tokens.
- `/api/update/access-token`: Renovación de access token.
- `/api/revoke/token`: Cierre de sesión (revocación).
